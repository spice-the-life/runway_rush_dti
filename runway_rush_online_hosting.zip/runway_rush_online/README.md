# Runway Rush — 3D fashion battle

A playable web prototype with a Three.js 3D scene, customizable mannequin, clothes/hair/shoes/accessories, color studio, theme rotation, runway lock-in, and a Socket.IO room server.

## Easiest online setup (no Command Prompt needed on your computer)

This project includes `render.yaml` so a host can build and run the Node server. You will need a GitHub account and a Render account, and you must be allowed to access those sites.

1. Sign in to GitHub and create a **new repository** named `runway-rush-online`.
2. On the new repository page, choose **Add file → Upload files**.
3. Open the extracted `runway_rush_online` folder on your computer and upload the project files and the `public` folder. Make sure `package.json`, `server.js`, and `render.yaml` are at the repository's top level, and `index.html` is inside `public`.
4. Commit/upload the files to GitHub.
5. Sign in to Render and choose **New + → Web Service**. Connect the `runway-rush-online` GitHub repository.
6. If Render asks for settings, use:
   - Runtime: Node
   - Build command: `npm install`
   - Start command: `npm start`
   - Health check path: `/`
7. Create/deploy the service and wait for the build to finish. Render will give you a public `https://...onrender.com` URL. Open that URL to play and share it with friends.

Render's free service may sleep when idle, so the first visit after a while can take some time to load. Hosting providers and account requirements can change.

## Run locally (optional)

1. Install Node.js 18 or newer.
2. Open a terminal in this folder.
3. Run `npm install`, then `npm start`.
4. Open `http://localhost:3000`.

## Test multiplayer

- Create a room in one browser and share the room code.
- Friends open the same deployed URL, enter the room code, and join.
- The server supports up to 8 players per room in this prototype.

## What's real / what's still prototype

- Real 3D rendering and orbiting the model: yes (Three.js).
- Clothing choices and recoloring: yes; stylized primitive geometry rather than production-quality cloth or purchased 3D assets.
- Room codes and live player presence: yes when the Node server is running.
- Persistent accounts, save data, anti-cheat, moderation/reporting, robust matchmaking, synchronized 3D player avatars, and a full timed voting phase: not yet implemented.
- Multiplayer votes/scores are an early prototype; the vote button currently uses a placeholder target and should be expanded into a player-select voting UI before public release.

This is a starter game project, not a finished commercial game. Hosting it makes the site reachable, but does not add the unfinished features above.
